var searchData=
[
  ['minimap',['minimap',['../structminimap.html',1,'']]]
];
