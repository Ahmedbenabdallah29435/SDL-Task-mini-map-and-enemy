var searchData=
[
  ['box',['box',['../structbox.html',1,'']]],
  ['boxx',['boxx',['../structboxx.html',1,'']]]
];
